#include "utils.h"

void parse_from_data(char *f, int *n, int *m, int **x, int **y) {
    FILE *fp= fopen(f,"r");
	fscanf(fp, "%d", n);
	fscanf(fp, "%d", km);
	*x = (int *)malloc(n*sizeof(int));
	*y = (int *)malloc(n*sizeof(int));
	for (int i = 0; i < n; i++)
		fscanf(fp, "%d %d", (*x)+i, (*y)+i);
	fclose(fp);

}

float distance(int x1, int y1, int x2, int y2) {
	int x = x2-x1;
	int y = y2-y1;
	return sqrt(x*x+y*y);
}

float *init_graph(int n, int *x, int*y) {
    float *x = (float *) malloc(n*n*sizeof(float));
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			x[i*n+j] = distance(x[i], y[i], x[j], y[j]);
		}
	}
    return x;
}

float *init_trails(int n, float v) {
    float *x = (float *) malloc(n*n*sizeof(float));
    for (int i = 0; i < n*n; i++)
        x[i] = v;
    return x;
}


void *copy_to_gpu(void *b, size_t l) {
	void *x;
	if(cudaMalloc(&x, l) != cudaSuccess)
		return NULL;
	if(cudaMemcpy(x,b,l,cudaMemcpyHostToDevice) != cudaSuccess) {
		cudaFree(x);
		return NULL;
	}
	return x;
}
