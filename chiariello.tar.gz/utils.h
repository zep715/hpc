#ifndef UTILS_H
#define UTILS_H

void parse_from_data(char *, int *, int*, int**, int**);
float distance(int,int,int,int);
float *init_graph(int, int*, int*);
float *init_trails(int, float);
void *gpucopy(void *, size_t);


#endif
